﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.DataTransferObjects;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new ProductShopContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();

            //==================== T01 ===========================
            //var readJsonFile = File.ReadAllText("../../../Datasets/users.json");
            //var result = ImportUsers(db, readJsonFile);

            //==================== T02 ===========================
            var readJsonFile = File.ReadAllText("../../../Datasets/products.json");
            var result = ImportProducts(db, readJsonFile);

            Console.WriteLine(result);
        }

        //============================= T02 ==========================================

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            var mappConfig = new MapperConfiguration(cfg => cfg.AddProfile<ProductShopProfile>());
            var mapper = mappConfig.CreateMapper();

            var productsDto = JsonConvert.DeserializeObject<IEnumerable<ProductInputModel>>(inputJson);
            var products = mapper.Map<IEnumerable<Product>>(productsDto);

            context.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }

        //============================= T01 ==========================================

        //public static string ImportUsers(ProductShopContext context, string inputJson)
        //{
        //    var mappConfig = new MapperConfiguration(cfg => cfg.AddProfile<ProductShopProfile>());
        //    var mapper = mappConfig.CreateMapper();

        //    var usersDto = JsonConvert.DeserializeObject<IEnumerable<UserInputModel>>(inputJson);
        //    var users = mapper.Map<IEnumerable<User>>(usersDto);

        //    context.AddRange(users);
        //    context.SaveChanges();

        //    return $"Successfully imported {users.Count()}";
        //}
    }
}