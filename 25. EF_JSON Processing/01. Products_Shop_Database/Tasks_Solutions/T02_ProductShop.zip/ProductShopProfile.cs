﻿namespace ProductShop
{
    using AutoMapper;
    using ProductShop.DataTransferObjects;
    using ProductShop.Models;

    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            CreateMap<UserInputModel, User>();
            CreateMap<ProductInputModel, Product>();
        }
    }
}
