﻿namespace CarDealer.DTO
{
    using System;

    public class CustomersExportDto
    {
        public string Name { get; set; }
        public string BirthDate { get; set; }
        public bool IsYoungDriver { get; set; }
    }
}
