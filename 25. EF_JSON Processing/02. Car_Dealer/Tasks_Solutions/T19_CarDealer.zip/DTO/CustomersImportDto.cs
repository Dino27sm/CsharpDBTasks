﻿namespace CarDealer.DTO
{
    using System;

    public class CustomersImportDto
    {
        public string name { get; set; }
        public DateTime birthDate { get; set; }
        public bool isYoungDriver { get; set; }
    }
}
