﻿namespace CarDealer.DTO
{
    public class SalesExportDto
    {
        public string fullName { get; set; }
        public int boughtCars { get; set; }
        public decimal spentMoney { get; set; }
    }
}
