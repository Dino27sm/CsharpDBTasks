﻿namespace CarDealer.DTO
{

    public class SuppliersImportDto
    {
        public string name { get; set; }
        public bool isImporter { get; set; }
    }
}
