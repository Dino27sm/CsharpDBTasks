﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using CarDealer.DTO;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();

            //string suppliersJson = File.ReadAllText("../../../Datasets/suppliers.json");
            //var suppliersResult = ImportSuppliers(db, suppliersJson);

            string partsJson = File.ReadAllText("../../../Datasets/parts.json");
            var partsResult = ImportParts(db, partsJson);

            Console.WriteLine(partsResult);

        }

        //============================== T10 ===========================================

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var mappConfig = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
            var mapper = mappConfig.CreateMapper();

            var partsDto = JsonConvert.DeserializeObject<ICollection<PartsImportDto>>(inputJson);
            var partsAll = mapper.Map<ICollection<Part>>(partsDto);

            var suppliersId = context.Suppliers.Select(s => s.Id).ToList();
            var parts = partsAll.Where(p => suppliersId.Contains(p.SupplierId)).ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}.";
        }

        //============================== T09 ===========================================

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var mappConfig = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
            var mapper = mappConfig.CreateMapper();

            var suppliersDto = JsonConvert.DeserializeObject<ICollection<SuppliersImportDto>>(inputJson);
            var suppliers = mapper.Map<ICollection<Supplier>>(suppliersDto);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
    }
}