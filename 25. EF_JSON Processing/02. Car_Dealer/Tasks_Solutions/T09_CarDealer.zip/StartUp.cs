﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using CarDealer.DTO;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();

            string fileJson = File.ReadAllText("../../../Datasets/suppliers.json");

            Console.WriteLine(ImportSuppliers(db, fileJson));
        }
        //============================== T09 ===========================================

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var mappConfig = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
            var mapper = mappConfig.CreateMapper();

            var suppliersDto = JsonConvert.DeserializeObject<ICollection<SuppliersImportDto>>(inputJson);
            var suppliers = mapper.Map<ICollection<Supplier>>(suppliersDto);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
    }
}