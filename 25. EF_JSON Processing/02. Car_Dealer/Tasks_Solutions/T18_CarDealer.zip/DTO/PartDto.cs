﻿namespace CarDealer.DTO
{
    public class PartDto
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}
