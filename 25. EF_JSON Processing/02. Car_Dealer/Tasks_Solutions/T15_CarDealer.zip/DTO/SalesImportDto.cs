﻿
namespace CarDealer.DTO
{
    public class SalesImportDto
    {
        public int carId { get; set; }
        public int customerId { get; set; }
        public decimal discount { get; set; }
    }
}
