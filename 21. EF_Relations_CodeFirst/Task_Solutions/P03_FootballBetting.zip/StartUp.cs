﻿namespace P03_FootballBetting
{
    using P03_FootballBetting.Data;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var fbs = new FootballBettingContext();
            fbs.Database.EnsureDeleted();
            fbs.Database.EnsureCreated();

        }
    }
}
