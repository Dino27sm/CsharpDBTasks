﻿namespace P03_FootballBetting.Data
{
    using Microsoft.EntityFrameworkCore;
    using P03_FootballBetting.Data.Models;

    public class FootballBettingContext : DbContext
    {
        public FootballBettingContext()
        {

        }
        public FootballBettingContext(DbContextOptions options)
            :base(options)
        {

        }

        public DbSet<Color> Colors { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Position> Positions { get; set; }
        public DbSet<Town> Towns { get; set; }
        public DbSet<Country> Countries { get; set; }
        public DbSet<Bet> Bets { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<Player> Players { get; set; }
        public DbSet<PlayerStatistic> PlayerStatistics { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // "Server=<ServerName>; Database=<DatabaseName>; Integrated Security=True;"
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=.; Database=FootballBookmakerSystem;Integrated Security=True;");
            }
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PlayerStatistic>()
                .HasKey(pk => new { pk.GameId, pk.PlayerId });

            modelBuilder.Entity<Team>(entity =>
            {
                entity
                .HasOne(x => x.PrimaryKitColor)
                .WithMany(y => y.PrimaryKitTeams)
                .OnDelete(DeleteBehavior.NoAction);

                entity
                .HasOne(x => x.SecondaryKitColor)
                .WithMany(y => y.SecondaryKitTeams)
                .OnDelete(DeleteBehavior.NoAction);
            });

            modelBuilder.Entity<Game>(entity =>
            {
                entity
                .HasOne(x => x.HomeTeam)
                .WithMany(y => y.HomeGames)
                .OnDelete(DeleteBehavior.NoAction);

                entity
                .HasOne(x => x.AwayTeam)
                .WithMany(y => y.AwayGames)
                .OnDelete(DeleteBehavior.NoAction);
            });
        }
    }
}
