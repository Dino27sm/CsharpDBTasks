﻿namespace MusicHub.Data.Models.Enums
{
    public enum Genre
    {
        Blues = 10,
        Rap = 20,
        PopMusic = 30,
        Rock = 40,
        Jazz = 50
    }
}
