﻿namespace MusicHub
{
    using MusicHub.Data;
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var dbMusicHub = new MusicHubDbContext();
            //dbMusicHub.Database.EnsureDeleted();
            //dbMusicHub.Database.EnsureCreated();

        }
    }
}
