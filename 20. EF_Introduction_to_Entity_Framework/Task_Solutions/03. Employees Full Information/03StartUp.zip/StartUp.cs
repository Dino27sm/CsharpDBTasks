﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();

            Console.WriteLine(GetEmployeesFullInformation(db));
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employeeInfo = context.Employees.OrderBy(x => x.EmployeeId)
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.MiddleName,
                    x.JobTitle,
                    x.Salary
                }).ToList();
            foreach (var item in employeeInfo)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} {item.MiddleName} " +
                    $"{item.JobTitle} {item.Salary:F2}");
            }
            return sb.ToString().Trim();
        }
    }
}
