﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetDepartmentsWithMoreThan5Employees(db));
        }

        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var infoDepartment = context.Departments
                .Where(x => x.Employees.Count > 5)
                .OrderBy(x => x.Employees.Count)
                .ThenBy(x => x.Name)
                .Select(x => new
                {
                    departName = x.Name,
                    mngFirstName = x.Manager.FirstName,
                    mngLastName = x.Manager.LastName,
                    employList = x.Employees.Select(y => new
                    {
                        y.FirstName, y.LastName, y.JobTitle
                    }).OrderBy(z => z.FirstName).ThenBy(z => z.LastName).ToList()
                }).ToList();

            foreach (var department in infoDepartment)
            {
                sb.AppendLine($"{department.departName} - {department.mngFirstName} " +
                              $"{department.mngLastName}");
                foreach (var departMember in department.employList)
                {
                    sb.AppendLine($"{departMember.FirstName} {departMember.LastName} - " +
                                  $"{departMember.JobTitle}");
                }
            }
            return sb.ToString().Trim();
        }
    }
}
