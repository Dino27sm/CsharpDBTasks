﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetEmployee147(db));
        }

        public static string GetEmployee147(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var infoEmployee147 = context.Employees
                .Where(x => x.EmployeeId == 147)
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.JobTitle,
                    projectsOf147 = x.EmployeesProjects.Select(y => y.Project)
                }).ToList();
            foreach (var employee in infoEmployee147)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} - {employee.JobTitle}");
                foreach (var projectItems in employee.projectsOf147.OrderBy(x => x.Name))
                {
                    sb.AppendLine($"{projectItems.Name}");
                }
            }
            return sb.ToString().Trim();
        }
    }
}
