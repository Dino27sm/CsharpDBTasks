﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(DeleteProjectById(db));
        }

        public static string DeleteProjectById(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var project2 = context.Projects.FirstOrDefault(x => x.ProjectId == 2);
            var emploeeWithProject2 = context.EmployeesProjects.Where(x => x.Project == project2).ToList();

            foreach (var project in emploeeWithProject2)
            {
                context.EmployeesProjects.Remove(project);
            }
            context.Projects.Remove(project2);
            context.SaveChanges();

            var firstTen = context.Projects.Select(x => new { x.Name }).Take(10).ToList();

            foreach (var project in firstTen)
            {
                sb.AppendLine($"{project.Name}");
            }
            return sb.ToString().Trim();
        }
    }
}
