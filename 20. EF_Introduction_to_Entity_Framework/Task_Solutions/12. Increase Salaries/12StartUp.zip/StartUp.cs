﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(IncreaseSalaries(db));
        }

        public static string IncreaseSalaries(SoftUniContext context)
        {
            string[] highSalaryDep = { "Engineering", "Tool Design", "Marketing", "Information Services" };
            StringBuilder sb = new StringBuilder();

            var employeesForNewSalary = context.Employees
                .Where(x => highSalaryDep.Contains(x.Department.Name))
                .ToList();

            foreach (var employee in employeesForNewSalary)
            {
                employee.Salary *= 1.12M;
            }

            context.SaveChanges();

            var getEmployeesWithNewSalary = context.Employees
                .Where(x => highSalaryDep.Contains(x.Department.Name))
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.Salary
                })
                .OrderBy(y => y.FirstName)
                .ThenBy(y => y.LastName)
                .ToList();

            foreach (var employee in getEmployeesWithNewSalary)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} (${employee.Salary:F2})");
            }
            return sb.ToString().Trim();
        }
    }
}
