﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetEmployeesByFirstNameStartingWithSa(db));
        }

        public static string GetEmployeesByFirstNameStartingWithSa(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employeeSA = context.Employees
                .Where(x => x.FirstName.ToLower().StartsWith("sa"))
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.JobTitle,
                    x.Salary
                })
                .OrderBy(y => y.FirstName)
                .ThenBy(y => y.LastName)
                .ToList();

            foreach (var itemSA in employeeSA)
            {
                sb.AppendLine($"{itemSA.FirstName} {itemSA.LastName} - " +
                              $"{itemSA.JobTitle} - (${itemSA.Salary:F2})");
            }
            return sb.ToString().Trim();
        }
    }
}
