﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(AddNewAddressToEmployee(db));
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var objectNakov = context.Employees
                .FirstOrDefault(x => x.LastName == "Nakov");

            var newAddress = new Address();
            newAddress.AddressText = "Vitoshka 15";
            newAddress.TownId = 4;

            objectNakov.Address = newAddress;
            context.SaveChanges();

            var addressText = context.Employees
                .OrderByDescending(x => x.AddressId)
                .Take(10)
                .Select(x => x.Address.AddressText)
                .ToList();

            foreach (var currentAddress in addressText)
            {
                sb.AppendLine(currentAddress);
            }
            return sb.ToString().Trim();
        }
    }
}
