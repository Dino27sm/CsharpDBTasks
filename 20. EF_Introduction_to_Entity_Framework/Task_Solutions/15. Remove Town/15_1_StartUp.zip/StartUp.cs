﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;


namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(RemoveTown(db));
        }

        public static string RemoveTown(SoftUniContext context)
        {
            var townDel = context.Towns.FirstOrDefault(x => x.Name == "Seattle");
            var addressesDel = context.Addresses.Where(x => x.TownId == townDel.TownId);
            int addressesDeletedNum = addressesDel.Count();

            var employeeAddressIdToNull = context.Employees
                .Where(x => addressesDel.Any(y => y.AddressId == x.AddressId));

            foreach (var employeeItem in employeeAddressIdToNull)
            {
                employeeItem.AddressId = null;
            }
            foreach (var addressItem in addressesDel)
            {
                context.Addresses.Remove(addressItem);
            }
            context.Towns.Remove(townDel);
            context.SaveChanges();

            return $"{addressesDeletedNum} addresses in Seattle were deleted";
        }
    }
}
