﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetLatestProjects(db));
        }

        public static string GetLatestProjects(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var latestProjects = context.Projects
                .OrderBy(x => x.StartDate).ToList()
                .TakeLast(10)
                .OrderBy(y => y.Name).ToList();

            foreach (var projectItem in latestProjects)
            {
                sb.AppendLine($"{projectItem.Name}");
                sb.AppendLine($"{projectItem.Description}");
                sb.AppendLine($"{projectItem.StartDate.ToString("M/d/yyyy h:mm:ss tt")}");
            }
            return sb.ToString().Trim();
        }
    }
}
