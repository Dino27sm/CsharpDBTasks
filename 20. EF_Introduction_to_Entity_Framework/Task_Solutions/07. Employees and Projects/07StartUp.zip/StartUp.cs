﻿using System;
using SoftUni.Data;
using SoftUni.Models;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetEmployeesInPeriod(db));
        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employeeInfo = context.Employees
                .Where(x => x.EmployeesProjects.Any(y => y.Project.StartDate.Year >= 2001
                                    && y.Project.StartDate.Year <= 2003))
                .Select(x => new
                {
                    x.FirstName, x.LastName,
                    ManagerFirstName = x.Manager.FirstName,
                    ManagerLastName = x.Manager.LastName,
                    Project = x.EmployeesProjects.Select(z => new
                        {
                            ProjectName = z.Project.Name,
                            StartDate = z.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt"),
                            EndDate = z.Project.EndDate.HasValue ? 
                                z.Project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt") : "not finished"
                        })
                }).Take(10).ToList();

            foreach (var employeeItem in employeeInfo)
            {
                sb.AppendLine($"{employeeItem.FirstName} {employeeItem.LastName}" +
                    $" - Manager: {employeeItem.ManagerFirstName} {employeeItem.ManagerLastName}");
                foreach (var projectItem in employeeItem.Project)
                {
                    sb.AppendLine($"--{projectItem.ProjectName} - " +
                        $"{projectItem.StartDate} - " +
                        $"{projectItem.EndDate}");
                }
            }
            return sb.ToString().Trim();
        }
    }
}
