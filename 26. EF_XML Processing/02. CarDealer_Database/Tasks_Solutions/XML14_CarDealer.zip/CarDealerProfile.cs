﻿namespace CarDealer
{
    using AutoMapper;
    using CarDealer.Models;
    using CarDealer.DtoModels.InputDto;

    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {

        }
    }
}
