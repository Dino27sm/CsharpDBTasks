﻿namespace CarDealer
{
    using CarDealer.Data;
    using CarDealer.DtoModels.InputDto;
    using CarDealer.Models;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();

            string xmlSuppliers = File.ReadAllText("../../../Datasets/suppliers.xml");

            string printOut = ImportSuppliers(db, xmlSuppliers);
            Console.WriteLine(printOut);
        }

        //======================= T09 ==================================================

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(SuppliersInputDto[]), 
                new XmlRootAttribute("Suppliers"));
            var deserializedSuppliers = (ICollection<SuppliersInputDto>)serializer
                .Deserialize(new StringReader(inputXml));

            var suppliers = deserializedSuppliers
                .Select(s => new Supplier
                {
                    Name = s.Name,
                    IsImporter = s.IsImporter
                })
                .ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }
    }
}