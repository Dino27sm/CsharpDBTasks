﻿namespace CarDealer
{
    using CarDealer.Data;
    using CarDealer.DtoModels.InputDto;
    using CarDealer.Models;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();

            var xmlParts = File.ReadAllText("../../../Datasets/parts.xml");

            string printOut = ImportParts(db, xmlParts);
            Console.WriteLine(printOut);
        }

        //======================= T10 ==================================================

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(PartsInputDto[]), 
                new XmlRootAttribute("Parts"));
            var deserializedParts = (PartsInputDto[])serializer
                .Deserialize(new StringReader(inputXml));

            var suppliersId = context.Suppliers.Select(s => s.Id).ToList();
            var parts = deserializedParts
                .Where(p => suppliersId.Contains(p.SupplierId))
                .Select(p => new Part
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }

        //======================= T09 ==================================================

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(SuppliersInputDto[]), 
                new XmlRootAttribute("Suppliers"));
            var deserializedSuppliers = (ICollection<SuppliersInputDto>)serializer
                .Deserialize(new StringReader(inputXml));

            var suppliers = deserializedSuppliers
                .Select(s => new Supplier
                {
                    Name = s.Name,
                    IsImporter = s.IsImporter
                })
                .ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }
    }
}