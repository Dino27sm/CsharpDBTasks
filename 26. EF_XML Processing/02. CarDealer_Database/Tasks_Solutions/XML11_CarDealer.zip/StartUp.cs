﻿namespace CarDealer
{
    using CarDealer.Data;
    using CarDealer.DtoModels.InputDto;
    using CarDealer.Models;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();

            var xmlSuppliers = File.ReadAllText("../../../Datasets/suppliers.xml");
            var suppliersOut = ImportSuppliers(db, xmlSuppliers);

            var xmlParts = File.ReadAllText("../../../Datasets/parts.xml");
            var partsOut = ImportParts(db, xmlParts);

            var xmlCars = File.ReadAllText("../../../Datasets/cars.xml");
            var carsOut = ImportCars(db, xmlCars);

            Console.WriteLine(carsOut);
        }

        //======================= T11 ==================================================

        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(CarInputDto[]), new XmlRootAttribute("Cars"));
            var deserializedCars = (ICollection<CarInputDto>)serializer.Deserialize(new StringReader(inputXml));

            var partIds = context.Parts.Select(p => p.Id).ToList();
            List<Car> cars = new List<Car>();
            foreach (var carDto in deserializedCars)
            {
                Car currentCar = new Car
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TravelledDistance = carDto.TravelledDistance,
                };
                foreach (var partDtoId in carDto.Parts.Select(x => x.Id).Distinct())
                {
                    if (partIds.Contains(partDtoId))
                    {
                        currentCar.PartCars.Add(new PartCar
                        {
                            PartId = partDtoId
                        });
                    }
                }
                cars.Add(currentCar);
            }

            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }

        //======================= T10 ==================================================

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(PartInputDto[]), 
                new XmlRootAttribute("Parts"));
            var deserializedParts = (ICollection<PartInputDto>)serializer
                .Deserialize(new StringReader(inputXml));

            var suppliersId = context.Suppliers.Select(s => s.Id).ToList();
            var parts = deserializedParts
                .Where(p => suppliersId.Contains(p.SupplierId))
                .Select(p => new Part
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }

        //======================= T09 ==================================================

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            var serializer = new XmlSerializer(typeof(SupplierInputDto[]), 
                new XmlRootAttribute("Suppliers"));
            var deserializedSuppliers = (ICollection<SupplierInputDto>)serializer
                .Deserialize(new StringReader(inputXml));

            var suppliers = deserializedSuppliers
                .Select(s => new Supplier
                {
                    Name = s.Name,
                    IsImporter = s.IsImporter
                })
                .ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }
    }
}